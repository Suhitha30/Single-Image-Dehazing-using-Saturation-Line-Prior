%Taking in the images and putting the origin on the bottom left corner
imageA =imread('1.tiff');
imageB = imread('2.tiff');
[xmax, ymax] = size(imageA);

%window sizes
wsize = [32,32];
w_width = wsize(1);
w_height = wsize(2);

%centre points grid
